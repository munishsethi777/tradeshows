<?php
require_once($ConstantsArray['dbServerUrl'] ."Enums/BasicEnum.php");
class CustomerNameType extends BasicEnum{
	const ALPINE = "ALPINE";
	const ACE = "ACE";
	const AUBUCHON = "AUBUCHON";
	const BFG_SUPPLY = "BFG SUPPLY";
	const BOMGAARS = "BOMGAARS";
	const BOSCOVS = "BOSCOVS";
	const CAL_RANCH = "CAL_RANCH";
	const DO_IT_BEST = "DO_IT_BEST";
	const ENGLISH_GARDENS = "AUBUCHON";
	const FRED_MEYER = "AUBUCHON";
	const GREENSTAR = "AUBUCHON";
	const HAYNEEDLE = "AUBUCHON";
	const IMPROVEMENTS = "AUBUCHON";
	const JAVIC = "AUBUCHON";
	const MEIJER = "AUBUCHON";
	const MENARDS = "AUBUCHON";
	const MID_STATES = "MID-STATES";
	const MILLS = "MILLS";
	const ORSCHELN = "ORSCHELN";
	const PEAVEY = "PEAVEY";
	const PRO_SOURCE_SHOP = "PRO SOURCE SHOP";
	const QUINCY = "QUINCY";
	const QVC = "QVC";
	const RUNNINGS = "RUNNING'S";
	const RURAL_KING = "RURAL KING";
	const SBARS = "SBAR'S";
	const SHOPKO = "SHOPKO";
	const TRUE_VALUE = "TRUE VALUE";
	const KROGER = "KROGER";
	const BURLINGTON = "BURLINGTON";
	const SUPERVALUE = "SUPERVALUE";
	const THEISENS = "THEISENS";
}

