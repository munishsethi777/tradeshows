<?php
require_once($ConstantsArray['dbServerUrl'] ."Enums/BasicEnum.php");
class LabelType extends BasicEnum{
	const a4 = "A4";
	const custom = "Custom";
}