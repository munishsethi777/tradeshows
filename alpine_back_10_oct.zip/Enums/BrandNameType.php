<?php
require_once($ConstantsArray['dbServerUrl'] ."Enums/BasicEnum.php");
class BrandNameType extends BasicEnum{
	const ARTISAN = "Artisan";
	const CASCADING_FOUNTAIN = "Cascading Fountain";
	const FURNITURE = "Furniture";
	const GAZING_GLOBE_COLLECTION = "Gazing Globe Collection";
	const HOLIDAY = "Holiday";
	const H_G_ACCENTS = "H&G Accents";
	const PATRIOTIC = "Patriotic";
	const SOL_SOUND = "Sol Sound";
	const SOLARIS = "Solaris";
}