<?php
require_once($ConstantsArray['dbServerUrl'] ."Enums/BasicEnum.php");
class TruckerType extends BasicEnum{
    const alpine = "KKG";
    const cbl = "CBL";
    const m_and_a_dcw = "M&A / DCW";
    const kkgr = "KKGR";
}