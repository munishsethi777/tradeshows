<tr>
	<td style="border:1px silver solid;width:5%;text-align:right">{SR_NO}</td>
	<td style="border:1px silver solid;width:10%;text-align:right">{QC_CODE}</td>
	<td style="border:1px silver solid;width:10%;text-align:right">{CLASS_CODE}</td>
	<td style="border:1px silver solid;width:10%;text-align:right">{PO_NO}</td>
	<td style="border:1px silver solid;width:10%;text-align:right">{PO_TYPE}</td>
	<td style="border:1px silver solid;width:10%;text-align:right">{ITEM_NUMBERS}</td>
	<td style="border:1px silver solid;width:10%;text-align:right">{FINAL_INSPECTION_DATE}</td>
	<td style="border:1px silver solid;width:10%;text-align:right">{APPLIED_ON}</td>
	<td style="border:1px silver solid;width:10%;text-align:right;color:red">{APPROVAL_STATUS}</td>
	
</tr>