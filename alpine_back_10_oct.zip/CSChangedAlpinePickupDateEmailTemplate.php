<div>
	<p>Hi,<br>
		{DETAIL}
	<br>
	<p>Regards,<br>Alpinebi
</div>