<p>Purchase orders submitted for approval with status "Pending"</p>
<table width="100%" style="color:grey;font-family:arial;font-weight:normal;font-size:12px;border:1px silver solid" cellpadding="3px" cellspacing="0px">
	<tr style="background-color: silver;color:white">
		<th style="border:1px silver solid;width:5%;text-align:right">Sr.</th>
		<th style="border:1px silver solid;width:10%;text-align:right">QC</th>
		<th style="border:1px silver solid;width:10%;text-align:right" >Class</th>
		<th style="border:1px silver solid;width:10%;text-align:right">PO</th>
		<th style="border:1px silver solid;width:10%;text-align:right">PO Type</th>
		<th style="border:1px silver solid;width:10%;text-align:right">Item Number</th>
		<th style="border:1px silver solid;width:10%;text-align:right">Final Inspection Date</th>
		<th style="border:1px silver solid;width:10%;text-align:right">Applied On</th>
		<th style="border:1px silver solid;width:10%;text-align:right">Approval Status</th>
	</tr>
	{TABLE_ROWS}
</table>