<div>
	<p>Hi,<br>
		Approval request for PO: {PO_NUMBER} Item: {ITEM_NUMBER} is marked as <b>{APPROVED_REJECT_STATUS}</b> by {SUPERVISOR_NAME}</p>
	<br>
	Comments : {RESPONSE_COMMENTS}
	<p>Regards,<br>Alpinebi
</div>