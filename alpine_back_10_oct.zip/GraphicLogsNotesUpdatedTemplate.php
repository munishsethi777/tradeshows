<div>
	<p>Hi <b>{FULL_NAME}</b>,<br>
	<p>Following are the {NOTES_NAME} notes updated by {LOGGED_IN_USER_NAME} for PO: <b>{PO_NUMBER}</b> and Item: <b>{ITEM_ID}</b></p>
	<p style="font-style: italic;">{NOTES_DETAIL}</p>
	<br>
	<p>Thanks<br>
</div>