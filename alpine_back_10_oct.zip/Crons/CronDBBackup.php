<?php
require_once('../IConstants.inc');
require_once($ConstantsArray['dbServerUrl'] ."Utils/DBBackupUtil.php");
Logger::configure ( $ConstantsArray ['dbServerUrl'] . "log4php/log4php.xml" );
try{
    $dbUtil = DBBackupUtil::getInstance();
    $dbUtil->runBackUpCommand();
}catch(Exception $e){
    echo $e->getMessage();
}