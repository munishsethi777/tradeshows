<?php
	 class DBvars{
		public $database = "alpinebi_tradeshows";
		//public $database = "alpinebi_test";
		public $username = "alpinebi_munish";
        public $password = "Munish#314";
        public $hostname = "localhost";
	}
 ?>