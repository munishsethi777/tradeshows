<html>
<body>
	<div
		style="background-color: #f3f3f4; width: 100%; color: #676a6c; font-family: open sans, Helvetica Neue, Helvetica, Arial, sans-serif">
		<div
			style="background-color: white; margin: auto; max-width: 800px; padding: 0px 15px 0px 15px">
			<div style="min-height: 700px;">
				<div
					style="padding: 10px; background-color: rgba(26, 178, 147, 0.3) !important; color: white; margin: 0px -15px 0px -15px;">
					<div style="width:30%;display:inline-table"><img src="http://www.alpinebi.com/images/logo.png" style="width:75%;align: left"></div>
					<div  style="width:65%;text-align:right;display:inline-table"><a href="http://www.alpinebi.com/"
						style="float: right; color: grey; text-decoration: none;">www.AlpineBI.com</a></div>
				</div>
				 {EMAIL_CONTENT}
			</div>
			<p style="background: #676a6c; margin: 0px -15px 0px -15px; color: #FFF; padding:10px;font-size:12px"	align="center">
				This is an automated email and can not be replied.</br>
				You may login at http://www.alpinebi.com to access Alpine Business Intelligence online application</br>
				© 2019 Alpine Corporation.
			</p>
		</div>
	</div>
</body>
</html>
