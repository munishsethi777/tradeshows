<?php
require_once ($ConstantsArray ['dbServerUrl'] . "log4php/Logger.php");
require_once($ConstantsArray['dbServerUrl'] ."DataStores/DBvars.php");
class DBBackUpUtil extends DBvars{
    private static $dbBackupUtil;
    public static function getInstance(){
        if(empty(self::$dbBackupUtil)){
            self::$dbBackupUtil = new DBBackUpUtil();
        }
        return self::$dbBackupUtil;
    }
    public function runBackUpCommand(){
       $backup_file = $this->database . date("Y-m-d-H-i-s") . '.sql 2>&1';
       $command = "mysqldump -u$this->username -p$this->password $this->database > $backup_file";
       passthru($command);
       var_dump($result);
       echo "<br />";
       var_dump($output);
       echo "<br />";
    }
}
?>