<div>
	<p>Hi,<br>
	<p>QC {QC_NAME} has submitted a request for your approval on Item {ITEM_ID} in PO. {PO_NUMBER} on dated {DATE_STR}.Please Login into webportal <a href='{WEB_PORTAL_LINK}'>{WEB_PORTAL_LINK}</a> to approve or reject the submission.</p>
	<br>
	<p>Regards,<br>Alpinebi
</div>