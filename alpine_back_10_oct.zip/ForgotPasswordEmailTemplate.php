<div>
<p>Hi,<br>
	You have asked to reset your password in Alpinebi.com.
</p>
<p>In order to get a reset your password, please <a href="{FOGOT_PASSWORD_LINK}">click this link.</a></p>
<br>
<p>Regards,<br>Alpinebi
</div>